/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_bonus.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/03 17:49:46 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/06 17:11:25 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CHECKER_BONUS_H
# define CHECKER_BONUS_H

# include <unistd.h>
# include <stdlib.h>

# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 10
# endif

typedef struct s_list
{
	int				data;
	long			index;
	struct s_list	*next;
}	t_list;

typedef struct s_arr
{
	char			*data;
	struct s_arr	*next;
}	t_arr;

void	ft_unique_list(t_list *list);
void	ft_check_list(int argc, char **argv);
void	ft_check_str(char *str);
t_list	*ft_fill_list(int argc, char **argv);
void	ft_get_list(char *str, t_list **list);

void	ft_checker_sort(t_list **list, t_arr **arr);
void	ft_checker_sorted(t_list *stack_a, t_list *stack_b);
int		ft_sort_check(t_list *list);
char	*ft_ischecked(char *str);
void	ft_fillcheck_arr(t_arr **arr, t_list **list);

int		ft_op(t_list **stack_a, t_list **stack_b, char *op);
void	ft_op_s(t_list **stack);
void	ft_op_ss(t_list **stack_a, t_list **stack_b);
void	ft_op_p(t_list **stack_a, t_list **stack_b);
void	ft_op_r(t_list **stack);
void	ft_op_rr(t_list **stack_a, t_list **stack_b);
void	ft_op_rt(t_list **stack);
void	ft_op_rrr(t_list **stack_a, t_list **stack_b);

long	ft_atoi(const char *str);
int		ft_strcmp(char *s1, char *s2);
int		ft_isvalid(char *str, int i);
size_t	ft_strlen(const char *s);
char	*ft_strchr(const char *s, int c);
char	*ft_strdup(const char *s1);
char	*ft_strjoin(char const *s1, char const *s2);
char	*get_next_line(int fd);

t_arr	*ft_arrnew(char *str);
t_arr	*ft_arrlast(t_arr *lst);
void	ft_arrback(t_arr **lst, t_arr *new);
void	ft_arrclear(t_arr **lst, void (*del)(void*));

t_list	*ft_lstnew(int n);
t_list	*ft_lstlast(t_list *lst);
void	ft_lstback(t_list **lst, t_list *new);
void	ft_lstclear(t_list **lst, void (*del)(void*));
int		ft_lstsize(t_list *list);

#endif

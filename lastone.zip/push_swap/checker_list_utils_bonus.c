/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_list_utils_bonus.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 21:07:36 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/06 17:11:44 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "checker_bonus.h"

int	ft_lstsize(t_list *list)
{
	int		i;

	i = 0;
	while (list)
	{
		list = list->next;
		i++;
	}
	return (i);
}

t_list	*ft_lstnew(int n)
{
	t_list	*my_node;

	my_node = (t_list *)malloc(sizeof(t_list));
	if (!my_node)
		return (NULL);
	my_node->data = n;
	my_node->index = -1;
	my_node->next = NULL;
	return (my_node);
}

t_list	*ft_lstlast(t_list *lst)
{
	t_list	*my_node;

	if (!lst)
		return (NULL);
	my_node = lst;
	while (my_node->next)
		my_node = my_node->next;
	return (my_node);
}

void	ft_lstback(t_list **lst, t_list *new)
{
	t_list	*my_node;

	if (lst && new)
	{
		if (*lst == NULL)
			*lst = new;
		else
		{
			my_node = ft_lstlast(*lst);
			my_node->next = new;
		}
	}
}

void	ft_lstclear(t_list **lst, void (*del)(void*))
{
	t_list	*my_node;

	if (lst && del)
	{
		while (*lst)
		{
			my_node = *lst;
			*lst = (*lst)->next;
			del(my_node);
		}
	}
}

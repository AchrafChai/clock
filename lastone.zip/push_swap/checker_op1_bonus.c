/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_op1_bonus.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/26 21:16:26 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/06 17:11:48 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "checker_bonus.h"

int	ft_op(t_list **stack_a, t_list **stack_b, char *op)
{
	if (!ft_strcmp(op, "sa"))
		return (ft_op_s(stack_a), 1);
	else if (!ft_strcmp(op, "sb"))
		return (ft_op_s(stack_b), 1);
	else if (!ft_strcmp(op, "ss"))
		return (ft_op_ss(stack_a, stack_b), 1);
	else if (!ft_strcmp(op, "pa"))
		return (ft_op_p(stack_a, stack_b), 1);
	else if (!ft_strcmp(op, "pb"))
		return (ft_op_p(stack_b, stack_a), 1);
	else if (!ft_strcmp(op, "ra"))
		return (ft_op_r(stack_a), 1);
	else if (!ft_strcmp(op, "rb"))
		return (ft_op_r(stack_b), 1);
	else if (!ft_strcmp(op, "rr"))
		return (ft_op_rr(stack_a, stack_b), 1);
	else if (!ft_strcmp(op, "rra"))
		return (ft_op_rt(stack_a), 1);
	else if (!ft_strcmp(op, "rrb"))
		return (ft_op_rt(stack_b), 1);
	else if (!ft_strcmp(op, "rrr"))
		return (ft_op_rrr(stack_a, stack_b), 1);
	return (0);
}

void	ft_op_s(t_list **stack)
{
	t_list	*temp;

	temp = NULL;
	if (ft_lstsize(*stack) > 1)
	{
		temp = (*stack);
		(*stack) = (*stack)->next;
		temp->next = (*stack)->next;
		(*stack)->next = temp;
	}
}

void	ft_op_ss(t_list **stack_a, t_list **stack_b)
{
	ft_op_s(stack_a);
	ft_op_s(stack_b);
}

void	ft_op_p(t_list **stack_a, t_list **stack_b)
{
	t_list	*temp;

	temp = NULL;
	if (ft_lstsize(*stack_b) > 0)
	{
		temp = (*stack_b);
		(*stack_b) = (*stack_b)->next;
		temp->next = (*stack_a);
		(*stack_a) = temp;
	}
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_arr_utils_bonus.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 21:07:36 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/06 17:10:51 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "checker_bonus.h"

t_arr	*ft_arrnew(char *str)
{
	t_arr	*my_node;

	my_node = (t_arr *)malloc(sizeof(t_arr));
	if (!my_node)
		return (NULL);
	my_node->data = str;
	my_node->next = NULL;
	return (my_node);
}

t_arr	*ft_arrlast(t_arr *arr)
{
	t_arr	*my_node;

	if (!arr)
		return (NULL);
	my_node = arr;
	while (my_node->next)
		my_node = my_node->next;
	return (my_node);
}

void	ft_arrback(t_arr **arr, t_arr *new)
{
	t_arr	*my_node;

	if (arr && new)
	{
		if (*arr == NULL)
			*arr = new;
		else
		{
			my_node = ft_arrlast(*arr);
			my_node->next = new;
		}
	}
}

void	ft_arrclear(t_arr **arr, void (*del)(void*))
{
	t_arr	*my_node;

	if (arr && del)
	{
		while (*arr)
		{
			my_node = *arr;
			*arr = (*arr)->next;
			del(my_node);
		}
	}
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_algo.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/30 17:48:26 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/02 17:30:17 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	ft_algo_easy(t_list **stack)
{
	int	elm1;
	int	elm2;

	elm1 = (*stack)->index;
	elm2 = (*stack)->next->index;
	if (elm1 == 1 && elm2 == 3)
	{
		ft_op(stack, NULL, "sa");
		ft_op(stack, NULL, "ra");
	}
	else if (elm1 == 2 && elm2 == 1)
		ft_op(stack, NULL, "sa");
	else if (elm1 == 2 && elm2 == 3)
		ft_op(stack, NULL, "rra");
	else if (elm1 == 3 && elm2 == 1)
		ft_op(stack, NULL, "ra");
	else if (elm1 == 3)
	{
		ft_op(stack, NULL, "sa");
		ft_op(stack, NULL, "rra");
	}
}

void	ft_algo_medium(t_list **stack_a, t_list **stack_b)
{
	t_list	*temp;
	int		i;
	int		j;

	i = 1;
	while (ft_lstsize(*stack_a) > 3)
	{
		temp = (*stack_a);
		j = 0;
		while (temp)
		{
			if (temp->index == i)
			{
				ft_algo_medium_sort(stack_a, stack_b, j);
				break ;
			}
			j++;
			temp = temp->next;
		}
		i++;
	}
	ft_index_init(stack_a);
	ft_algo_easy(stack_a);
	ft_op(stack_a, stack_b, "pa");
	ft_op(stack_a, stack_b, "pa");
}

void	ft_algo_hard(t_list **stack_a, t_list **stack_b, int rang, int sp)
{
	t_list	*temp;
	int		i;

	i = 0;
	while (ft_lstsize(*stack_a) > 0)
	{
		temp = (*stack_a);
		while (temp)
		{
			if (temp->index <= i || temp->index <= i + rang)
			{
				i += ft_op(stack_a, stack_b, "pb");
				if (ft_lstsize(*stack_b) > 1 && temp->index > i)
					(ft_op_r(stack_b), write(1, "rb\n", 3));
				break ;
			}
			if (sp)
				ft_op(stack_a, stack_b, "rra");
			else
				ft_op(stack_a, stack_b, "ra");
			break ;
			temp = temp->next;
		}
	}
}

void	ft_algo(t_list **stack_a, t_list **stack_b)
{
	int	rang;
	int	size;

	size = ft_lstsize(*stack_a);
	rang = (23 * size) / 400 + 6.25;
	if (size <= 3)
		return (ft_algo_easy(stack_a));
	else if (size <= 5)
		return (ft_algo_medium(stack_a, stack_b));
	if (ft_sp(*stack_a, size))
		ft_algo_hard(stack_a, stack_b, rang, 1);
	else
		ft_algo_hard(stack_a, stack_b, rang, 0);
	ft_algo_hard_sort(stack_a, stack_b);
}

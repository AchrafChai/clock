/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_bonus.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/03 17:49:01 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/06 20:29:26 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "checker_bonus.h"

char	*ft_ischecked(char *str)
{
	if (!ft_strcmp(str, "sa"))
		return ("sa");
	else if (!ft_strcmp(str, "sb"))
		return ("sb");
	else if (!ft_strcmp(str, "ss"))
		return ("ss");
	else if (!ft_strcmp(str, "pa"))
		return ("pa");
	else if (!ft_strcmp(str, "pb"))
		return ("pb");
	else if (!ft_strcmp(str, "ra"))
		return ("ra");
	else if (!ft_strcmp(str, "rb"))
		return ("rb");
	else if (!ft_strcmp(str, "rr"))
		return ("rr");
	else if (!ft_strcmp(str, "rra"))
		return ("rra");
	else if (!ft_strcmp(str, "rrb"))
		return ("rrb");
	else if (!ft_strcmp(str, "rrr"))
		return ("rrr");
	return (NULL);
}

void	ft_checker_sorted(t_list *stack_a, t_list *stack_b)
{
	if (ft_sort_check(stack_a) && stack_b == NULL)
		write(1, "OK\n", 3);
	else
		write(1, "KO\n", 3);
}

void	ft_checker_sort(t_list **list, t_arr **arr)
{
	t_list	*stack_a;
	t_list	*stack_b;
	t_arr	*temp;

	stack_a = *list;
	stack_b = NULL;
	temp = *arr;
	while (temp)
	{
		ft_op(&stack_a, &stack_b, temp->data);
		temp = temp->next;
	}
	*list = stack_a;
	ft_checker_sorted(stack_a, stack_b);
	ft_lstclear(&stack_b, free);
	ft_lstclear(&stack_a, free);
	ft_arrclear(arr, free);
}

void	ft_fillcheck_arr(t_arr **arr, t_list **list)
{
	char	*str;
	char	*op;

	str = get_next_line(0);
	while (str)
	{
		op = ft_ischecked(str);
		if (op)
			ft_arrback(arr, ft_arrnew(op));
		free(str);
		if (!op)
		{
			ft_arrclear(arr, free);
			ft_lstclear(list, free);
			get_next_line(-1);
			write(2, "Error\n", 6);
			exit(1);
		}
		str = get_next_line(0);
	}
	get_next_line(-1);
}

int	main(int argc, char **argv)
{
	t_list	*list;
	t_arr	*arr;

	if (argc < 2)
		return (0);
	ft_check_list(argc, argv);
	list = ft_fill_list(argc, argv);
	ft_unique_list(list);
	arr = NULL;
	ft_fillcheck_arr(&arr, &list);
	ft_checker_sort(&list, &arr);
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_utils.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/26 22:35:22 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/01 17:58:29 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

long	ft_atoi(const char *str)
{
	int					i;
	int					c;
	unsigned long long	s;

	i = 0;
	c = 1;
	s = 0;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	if (str[i] == '+' || str[i] == '-')
		if (str[i++] == '-')
			c = -c;
	while (str[i] >= '0' && str[i] <= '9')
	{
		if ((s == 922337203685477580 && str[i] > '7')
			|| (s > 922337203685477580))
		{
			if (c == 1)
				return (s);
			return (-s);
		}
		s = (s * 10) + (str[i] - 48);
		i++;
	}
	return ((long)(s * c));
}

int	ft_strcmp(char *s1, char *s2)
{
	int	i;
	int	cmp;

	i = 0;
	while (s1[i] || s2[i])
	{
		cmp = s1[i] - s2[i];
		if (cmp != 0)
			return (cmp);
		i++;
	}
	return (0);
}

int	ft_isvalid(char *str, int i)
{
	if ((str[i] == '+' || str[i] == '-')
		&& (str[i + 1] < '0' || str[i + 1] > '9'))
		return (0);
	if (str[i] != '+' && str[i] != '-' && str[i] != ' '
		&& (str[i] < '0' || str[i] > '9'))
		return (0);
	if (i > 0)
	{
		if ((str[i] == '+' || str[i] == '-') && str[i - 1] != ' ')
			return (0);
	}
	return (1);
}

void	ft_index_sort(t_list *stack, int *arr, int size)
{
	int		i;
	int		j;
	int		tmp;

	i = -1;
	while (stack)
	{
		arr[++i] = stack->data;
		stack = stack->next;
	}
	i = -1;
	while (++i < size - 1)
	{
		j = i;
		while (++j < size)
		{
			if (arr[i] > arr[j])
			{
				tmp = arr[i];
				arr[i] = arr[j];
				arr[j] = tmp;
			}
		}
	}
}

void	ft_index_fill(t_list **stack, int *arr, int size)
{
	t_list	*temp;
	int		i;

	temp = *stack;
	while (temp)
	{
		i = -1;
		while (++i < size)
		{
			if (temp->data == arr[i])
			{
				temp->index = i + 1;
				break ;
			}
		}
		temp = temp->next;
	}
}

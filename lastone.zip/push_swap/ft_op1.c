/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_op1.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/26 21:16:26 by acchairo          #+#    #+#             */
/*   Updated: 2025/01/31 19:10:49 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	ft_op(t_list **stack_a, t_list **stack_b, char *op)
{
	if (!ft_strcmp(op, "pb"))
		return (ft_op_p(stack_b, stack_a), write(1, "pb\n", 3), 1);
	else if (!ft_strcmp(op, "pa"))
		return (ft_op_p(stack_a, stack_b), write(1, "pa\n", 3), 1);
	else if (!ft_strcmp(op, "sa"))
		return (ft_op_s(stack_a), write(1, "sa\n", 3), 1);
	else if (!ft_strcmp(op, "sb"))
		return (ft_op_s(stack_b), write(1, "sb\n", 3), 1);
	else if (!ft_strcmp(op, "rb"))
		return (ft_op_r(stack_b), write(1, "rb\n", 3), 1);
	else if (!ft_strcmp(op, "ra"))
		return (ft_op_r(stack_a), write(1, "ra\n", 3), 1);
	else if (!ft_strcmp(op, "rrb"))
		return (ft_op_rt(stack_b), write(1, "rrb\n", 4), 1);
	else if (!ft_strcmp(op, "rra"))
		return (ft_op_rt(stack_a), write(1, "rra\n", 4), 1);
	return (0);
}

void	ft_op_s(t_list **stack)
{
	t_list	*temp;

	temp = NULL;
	if (ft_lstsize(*stack) > 1)
	{
		temp = (*stack);
		(*stack) = (*stack)->next;
		temp->next = (*stack)->next;
		(*stack)->next = temp;
	}
}

void	ft_op_ss(t_list **stack_a, t_list **stack_b)
{
	ft_op_s(stack_a);
	ft_op_s(stack_b);
}

void	ft_op_p(t_list **stack_a, t_list **stack_b)
{
	t_list	*temp;

	temp = NULL;
	if (ft_lstsize(*stack_b) > 0)
	{
		temp = (*stack_b);
		(*stack_b) = (*stack_b)->next;
		temp->next = (*stack_a);
		(*stack_a) = temp;
	}
}

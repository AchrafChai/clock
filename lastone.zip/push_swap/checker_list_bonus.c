/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_list_bonus.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 21:12:48 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/06 17:11:40 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "checker_bonus.h"

void	ft_unique_list(t_list *list)
{
	t_list	*my_node;
	t_list	*current;

	current = list;
	while (current)
	{
		my_node = current->next;
		while (my_node)
		{
			if (current->data == my_node->data)
			{
				ft_lstclear(&list, free);
				write(2, "Error\n", 6);
				exit(1);
			}
			my_node = my_node->next;
		}
		current = current->next;
	}
}

void	ft_get_list(char *str, t_list **list)
{
	int		i;
	long	n;

	i = 0;
	while (str[i])
	{
		if (str[i] == '+' || str[i] == '-' || (str[i] >= '0' && str[i] <= '9'))
		{
			n = ft_atoi(str + i);
			if (n > 2147483647 || n < -2147483648)
			{
				ft_lstclear(list, free);
				write(2, "Error\n", 6);
				exit(1);
			}
			ft_lstback(list, ft_lstnew(n));
		}
		while (str[i] == '+' || str[i] == '-'
			|| (str[i] >= '0' && str[i] <= '9'))
			i++;
		if (str[i] == ' ')
			i++;
	}
}

t_list	*ft_fill_list(int argc, char **argv)
{
	t_list	*list;
	int		i;

	i = 0;
	list = NULL;
	while (++i < argc)
		ft_get_list(argv[i], &list);
	return (list);
}

void	ft_check_str(char *str)
{
	int	i;
	int	isspace;
	int	iserr;

	i = -1;
	isspace = 1;
	iserr = 0;
	while (str[++i])
	{
		if (str[i] != ' ')
			isspace = 0;
		if (!ft_isvalid(str, i))
			iserr = 1;
	}
	if (isspace || iserr)
	{
		write (2, "Error\n", 6);
		exit(1);
	}
}

void	ft_check_list(int argc, char **argv)
{
	int	i;

	i = 0;
	while (++i < argc)
		ft_check_str(argv[i]);
}

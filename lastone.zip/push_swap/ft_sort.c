/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/27 19:14:45 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/03 17:54:13 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	ft_sort_check(t_list *list)
{
	int	data;

	data = list->data;
	while (list->next)
	{
		list = list->next;
		if (data > list->data)
			return (0);
		data = list->data;
	}
	return (1);
}

void	ft_index_init(t_list **stack)
{
	int		*arr;
	int		size;

	size = ft_lstsize(*stack);
	arr = (int *)malloc(sizeof(int) * size);
	if (!arr)
	{
		write(2, "Error\n", 6);
		ft_lstclear(stack, free);
		exit(1);
	}
	ft_index_sort(*stack, arr, size);
	ft_index_fill(stack, arr, size);
	free(arr);
}

void	ft_sort_list(t_list **list)
{
	t_list	*stack_a;
	t_list	*stack_b;

	stack_a = *list;
	stack_b = NULL;
	if (!ft_sort_check(stack_a))
	{
		ft_index_init(&stack_a);
		ft_algo(&stack_a, &stack_b);
	}
	*list = stack_a;
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_op2_bonus.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/26 22:02:13 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/06 17:11:47 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "checker_bonus.h"

void	ft_op_r(t_list **stack)
{
	t_list	*temp;
	t_list	*head;

	if (ft_lstsize(*stack) > 1)
	{
		temp = (*stack);
		head = (*stack);
		(*stack) = (*stack)->next;
		while (temp->next)
			temp = temp->next;
		temp->next = head;
		head->next = NULL;
	}
}

void	ft_op_rr(t_list **stack_a, t_list **stack_b)
{
	ft_op_r(stack_a);
	ft_op_r(stack_b);
}

void	ft_op_rt(t_list **stack)
{
	t_list	*head;
	t_list	*prev;

	head = *stack;
	prev = NULL;
	if (ft_lstsize(*stack) > 1)
	{
		while (head->next)
		{
			prev = head;
			head = head->next;
		}
		prev->next = NULL;
		head->next = (*stack);
		(*stack) = head;
	}
}

void	ft_op_rrr(t_list **stack_a, t_list **stack_b)
{
	ft_op_rt(stack_a);
	ft_op_rt(stack_b);
}

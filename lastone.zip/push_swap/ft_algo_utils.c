/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_algo_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/31 17:56:38 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/03 21:11:51 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	ft_algo_sort_done(t_list **stack_a, t_list **stack_b, int i, int *j)
{
	int	rang;

	rang = i / 2;
	if (rang == 0)
	{
		ft_op(stack_a, stack_b, "pa");
		return (1);
	}	
	if (*j <= rang)
	{
		while (--(*j))
			ft_op(stack_a, stack_b, "rb");
		ft_op(stack_a, stack_b, "pa");
		return (1);
	}
	else
	{
		while ((*j)++ != i + 1)
			ft_op(stack_a, stack_b, "rrb");
		ft_op(stack_a, stack_b, "pa");
		return (1);
	}
	return (0);
}

void	ft_algo_medium_sort(t_list **stack_a, t_list **stack_b, int j)
{
	int	size;

	size = ft_lstsize(*stack_a);
	if (j >= 3)
	{
		while (j != size)
		{
			ft_op(stack_a, NULL, "rra");
			j++;
		}
		ft_op(stack_a, stack_b, "pb");
	}
	else
	{
		while (j != 0)
		{
			ft_op(stack_a, NULL, "ra");
			j--;
		}
		ft_op(stack_a, stack_b, "pb");
	}
}

void	ft_algo_hard_sort(t_list **stack_a, t_list **stack_b)
{
	t_list	*temp;
	int		i;
	int		j;

	while (ft_lstsize(*stack_b) > 0)
	{
		temp = (*stack_b);
		j = 0;
		while (temp)
		{
			i = ft_lstsize(*stack_b);
			j++;
			if (temp->index == i)
			{
				if (ft_algo_sort_done(stack_a, stack_b, i, &j))
					break ;
			}
			temp = temp->next;
		}
	}
}

int	ft_sp(t_list *stack, int size)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (stack && j < (size / 2))
	{
		if (stack->data > stack->next->data)
			i++;
		stack = stack->next;
		j++;
	}
	if (i > (size / 3) + (size / 50))
		return (1);
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 14:38:33 by acchairo          #+#    #+#             */
/*   Updated: 2025/02/06 15:25:20 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <unistd.h>
# include <stdlib.h>

typedef struct s_list
{
	int				data;
	long			index;
	struct s_list	*next;
}	t_list;

void	ft_unique_list(t_list *list);
void	ft_check_list(int argc, char **argv);
void	ft_check_str(char *str);
t_list	*ft_fill_list(int argc, char **argv);
void	ft_get_list(char *str, t_list **list);

void	ft_sort_list(t_list **list);
int		ft_sort_check(t_list *list);

void	ft_index_init(t_list **stack);
void	ft_index_sort(t_list *stack, int *arr, int size);
void	ft_index_fill(t_list **stack, int *arr, int size);

void	ft_algo(t_list **stack_a, t_list **stack_b);
void	ft_algo_easy(t_list **stack);
void	ft_algo_medium(t_list **stack_a, t_list **stack_b);
void	ft_algo_medium_sort(t_list **stack_a, t_list **stack_b, int j);
void	ft_algo_hard(t_list **stack_a, t_list **stack_b, int rang, int sp);
void	ft_algo_hard_sort(t_list **stack_a, t_list **stack_b);
int		ft_algo_sort_done(t_list **stack_a, t_list **stack_b, int i, int *j);

int		ft_sp(t_list *stack, int size);

int		ft_op(t_list **stack_a, t_list **stack_b, char *op);
void	ft_op_s(t_list **stack);
void	ft_op_ss(t_list **stack_a, t_list **stack_b);
void	ft_op_p(t_list **stack_a, t_list **stack_b);
void	ft_op_r(t_list **stack);
void	ft_op_rr(t_list **stack_a, t_list **stack_b);
void	ft_op_rt(t_list **stack);

long	ft_atoi(const char *str);
int		ft_strcmp(char *s1, char *s2);
int		ft_isvalid(char *str, int i);

t_list	*ft_lstnew(int n);
t_list	*ft_lstlast(t_list *lst);
void	ft_lstback(t_list **lst, t_list *new);
void	ft_lstclear(t_list **lst, void (*del)(void*));
int		ft_lstsize(t_list *list);

#endif

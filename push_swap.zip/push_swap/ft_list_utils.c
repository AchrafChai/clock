/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap_utils.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 21:07:36 by acchairo          #+#    #+#             */
/*   Updated: 2025/01/25 21:08:49 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

long	ft_atoi(const char *str)
{
	int					i;
	int					c;
	unsigned long long	s;

	i = 0;
	c = 1;
	s = 0;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	if (str[i] == '+' || str[i] == '-')
		if (str[i++] == '-')
			c = -c;
	while (str[i] >= '0' && str[i] <= '9')
	{
		if ((s == 922337203685477580 && str[i] > '7')
			|| (s > 922337203685477580))
		{
			if (c == 1)
				return (s);
			return (-s);
		}
		s = (s * 10) + (str[i] - 48);
		i++;
	}
	return ((long)(s * c));
}

t_list	*ft_lstnew(int n)
{
	t_list	*my_node;

	my_node = (t_list *)malloc(sizeof(t_list));
	if (!my_node)
		return (NULL);
	my_node->data = n;
	my_node->next = NULL;
	return (my_node);
}

t_list	*ft_lstlast(t_list *lst)
{
	t_list	*my_node;

	if (!lst)
		return (NULL);
	my_node = lst;
	while (my_node->next)
		my_node = my_node->next;
	return (my_node);
}

void	ft_lstback(t_list **lst, t_list *new)
{
	t_list	*my_node;

	if (lst && new)
	{
		if (*lst == NULL)
			*lst = new;
		else
		{
			my_node = ft_lstlast(*lst);
			my_node->next = new;
		}
	}
}

void	ft_lstclear(t_list **lst, void (*del)(void*))
{
	t_list	*my_node;

	if (lst && del)
	{
		while (*lst)
		{
			my_node = *lst;
			*lst = (*lst)->next;
			del(my_node);
		}
	}
}


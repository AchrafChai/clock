/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/05 18:36:55 by acchairo          #+#    #+#             */
/*   Updated: 2025/01/25 18:56:41 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static t_list	*create_my_node(void *content, void *(*f)(void *),
	void (*del)(void *))
{
	void	*my_content;
	t_list	*my_node;

	my_content = f(content);
	if (!my_content)
		return (NULL);
	my_node = ft_lstnew(my_content);
	if (!my_node)
	{
		del(my_content);
		return (NULL);
	}
	return (my_node);
}

t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *))
{
	t_list	*my_new;
	t_list	*my_node;
	t_list	*my_last;

	if (!lst || !f || !del)
		return (NULL);
	my_new = NULL;
	my_last = NULL;
	while (lst)
	{
		my_node = create_my_node(lst->data, f, del);
		if (!my_node)
		{
			ft_lstclear(&my_new, del);
			return (NULL);
		}
		if (!my_new)
			my_new = my_node;
		else
			my_last->next = my_node;
		my_last = my_node;
		lst = lst->next;
	}
	return (my_new);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstsize_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/03 21:20:30 by acchairo          #+#    #+#             */
/*   Updated: 2025/01/25 18:55:51 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	ft_lstsize(t_list *lst)
{
	int		i;
	t_list	*my_node;

	i = 0;
	if (!lst)
		return (i);
	my_node = lst;
	while (my_node)
	{
		my_node = my_node->next;
		i++;
	}
	return (i);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/05 21:55:08 by acchairo          #+#    #+#             */
/*   Updated: 2024/11/18 16:16:28 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_split_count(const char *st, char c)
{
	size_t	i;
	size_t	j;
	size_t	t;

	i = 0;
	j = 0;
	t = 0;
	while (st[i])
	{
		if (st[i] == c)
			j = 0;
		else if (j == 0)
		{
			j = 1;
			t++;
		}
		i++;
	}
	return (t);
}

static void	ft_split_check(const char *s, char c, size_t *end)
{
	while (s[*end])
	{
		if (ft_strncmp(&s[*end], &c, 1) == 0)
			break ;
		(*end)++ ;
	}
}

static int	ft_is_alloc(char **str, int i)
{
	int	j;

	j = 0;
	while (j < i)
	{
		free(str[j]);
		j++;
	}
	free(str);
	return (0);
}

static int	ft_split_fill(char **str, const char *s, char c, size_t t)
{
	size_t	start;
	size_t	end;
	size_t	i;

	end = 0;
	i = 0;
	while (i < t)
	{
		while (s[end] == c)
			end++;
		start = end;
		ft_split_check(s, c, &end);
		str[i] = (char *)malloc((end - start + 1) * sizeof(char));
		if (!str[i])
			return (ft_is_alloc(str, i));
		ft_strlcpy(str[i], s + start, end - start + 1);
		i++;
		end++;
	}
	str[i] = NULL;
	return (1);
}

char	**ft_split(char const *s, char c)
{
	size_t	total;
	char	**str;

	if (!s)
		return (NULL);
	total = ft_split_count(s, c);
	str = (char **)malloc((total + 1) * sizeof(char *));
	if (!str)
		return (NULL);
	if (!ft_split_fill(str, s, c, total))
		return (NULL);
	return (str);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/25 19:17:12 by acchairo          #+#    #+#             */
/*   Updated: 2024/11/17 18:38:05 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t dstsize)
{
	size_t	i;
	size_t	j;
	size_t	l;

	j = ft_strlen(src);
	if (dstsize == 0)
		return (j);
	i = ft_strlen(dst);
	l = 0;
	if (dstsize <= i)
		return (dstsize + j);
	else
		j = j + i;
	while (src[l] && dstsize - i - 1)
	{
		dst[i] = src[l];
		i++;
		l++;
	}
	dst[i] = '\0';
	return (j);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/30 13:12:18 by acchairo          #+#    #+#             */
/*   Updated: 2024/11/10 20:09:05 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *haystack, const char *needle, size_t len)
{
	size_t	i;
	size_t	l;

	i = 0;
	l = ft_strlen(needle);
	if (l == 0 || (!haystack && len == 0))
		return ((char *)haystack);
	while (haystack[i] && l <= (len - i))
	{
		if (haystack[i] == needle[0]
			&& ft_strncmp(haystack + i, needle, l) == 0)
			return ((char *)haystack + i);
		i++;
	}
	return (NULL);
}

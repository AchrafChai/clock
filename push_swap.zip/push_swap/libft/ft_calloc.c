/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/28 21:38:45 by acchairo          #+#    #+#             */
/*   Updated: 2024/11/17 19:40:48 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_calloc(size_t count, size_t size)
{
	unsigned char	*str;
	size_t			i;
	size_t			s;

	if (size == 0 || count == 0)
		return (malloc(0));
	if (18446744073709551615U / size < count)
		return (NULL);
	s = size * count;
	str = malloc(s);
	if (!str)
		return (NULL);
	i = 0;
	while (i < s)
	{
		str[i] = 0;
		i++;
	}
	return (str);
}

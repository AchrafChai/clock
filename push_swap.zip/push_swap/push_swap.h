/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 14:38:33 by acchairo          #+#    #+#             */
/*   Updated: 2025/01/25 21:31:17 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <stdarg.h>
# include <unistd.h>
# include <stdlib.h>

typedef struct s_list
{
	int				data;
	struct s_list	*next;
}	t_list;

void	ft_check_list(int argc, char **argv);
void	ft_check_str(char *str);
t_list	*ft_fill_list(int argc, char **argv);
void	ft_get_list(char *str, t_list **list);

void	ft_sort(t_list **st_b);

long	ft_atoi(const char *str);

t_list	*ft_lstnew(int n);
t_list	*ft_lstlast(t_list *lst);
void	ft_lstback(t_list **lst, t_list *new);
void	ft_lstclear(t_list **lst, void (*del)(void*));

#endif
/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 14:37:42 by acchairo          #+#    #+#             */
/*   Updated: 2025/01/25 21:23:04 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	main(int argc, char **argv)
{
	t_list	*list;

	if (argc < 2)
		return (0);
	ft_check_list(argc, argv);
	list = ft_fill_list(argc, argv);
	ft_sort(&list);
	ft_lstclear(&list, free);
	return (0);
}
 
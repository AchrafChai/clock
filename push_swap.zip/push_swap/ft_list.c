/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acchairo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 21:12:48 by acchairo          #+#    #+#             */
/*   Updated: 2025/01/25 21:26:53 by acchairo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	ft_get_list(char *str, t_list **list)
{
	int		i;
	long	n;

	i = 0;
	while (str[i])
	{
		if (str[i] == '+' || str[i] == '-' || (str[i] >= '0' && str[i] <= '9'))
		{
			n = ft_atoi(str + i);
			if (n > 2147483647 || n < -2147483648)
			{
				ft_lstclear(list, free);
				write(2, "Error\n", 6);
				exit(0);
			}
			ft_lstback(list, ft_lstnew(n));
		}
		while (str[i] == '+' || str[i] == '-'
			|| (str[i] >= '0' && str[i] <= '9'))
			i++;
		if (str[i] == ' ')
			i++;
	}
}

t_list	*ft_fill_list(int argc, char **argv)
{
	t_list	*list;
	int		i;

	i = 0;
	list = NULL;
	while (++i < argc)
		ft_get_list(argv[i], &list);
	return (list);
}

void	ft_check_str(char *str)
{
	int	i;
	int	isspace;
	int	iserr;

	i = -1;
	isspace = 1;
	iserr = 0;
	while (str[++i])
	{
		if (str[i] != ' ')
			isspace = 0;
		if ((str[i] == '+' || str[i] == '-')
			&& (str[i + 1] < '0' || str[i + 1] > '9'))
			iserr = 1;
		if (str[i] != '+' && str[i] != '-' && str[i] != ' '
			&& (str[i] < '0' || str[i] > '9'))
			iserr = 1;
	}
	if (isspace || iserr)
	{
		write (2, "Error\n", 6);
		exit(0);
	}
}

void	ft_check_list(int argc, char **argv)
{
	int	i;

	i = 0;
	while (++i < argc)
		ft_check_str(argv[i]);
}
